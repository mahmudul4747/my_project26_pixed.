import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/models/product_model.dart';

import 'admin_provider.dart';

final productStreamProvider =
    StreamProvider<List<ProductModel>>((ref) {

  return ref
      .read(adminRepositoryProvider)
      .getProducts();

});