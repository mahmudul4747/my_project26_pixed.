import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/dashboard_stats_model.dart';
import '../models/product_model.dart';

class AdminRemoteDatasource {
  final FirebaseFirestore firestore =
      FirebaseFirestore.instance;

  // Dashboard Stats
  Future<DashboardStatsModel> getDashboardStats() async {
    final productSnap =
        await firestore.collection('products').get();

    final categorySnap =
        await firestore.collection('categories').get();

    final orderSnap =
        await firestore.collection('orders').get();

    double revenue = 0;

    for (final doc in orderSnap.docs) {
      revenue +=
          (doc['total'] ?? 0).toDouble();
    }

    return DashboardStatsModel(
      totalProducts: productSnap.docs.length,
      totalCategories: categorySnap.docs.length,
      totalOrders: orderSnap.docs.length,
      totalRevenue: revenue,
    );
  }

  // Products
  Stream<List<ProductModel>> getProducts() {
    return firestore
        .collection("products")
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map(
                (doc) => ProductModel.fromMap(
                  doc.data(),
                  doc.id,
                ),
              )
              .toList(),
        );
  }

  Future<void> addProduct(
      ProductModel product) async {
    await firestore
        .collection("products")
        .add(product.toMap());
  }

  Future<void> updateProduct(
      ProductModel product) async {
    await firestore
        .collection("products")
        .doc(product.id)
        .update(product.toMap());
  }

  Future<void> deleteProduct(
      String id,
  ) async {
    await firestore
        .collection("products")
        .doc(id)
        .delete();
  }
}